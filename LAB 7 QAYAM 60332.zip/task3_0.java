/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_7graph;

/**
 *
 * @author suban
 */
public class task3_0 {
    
 
    public static void main(String[] args) {
        int vertices = 5;
        int[][] graph = new int[vertices][vertices];

        // Add directed edges
        graph[0][1] = 1;
        graph[0][2] = 1;
        graph[1][2] = 1;
        graph[2][3] = 1;
        graph[3][1] = 1;

        // Display adjacency matrix
        System.out.println("Adjacency Matrix:");

        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + "  ");
            }
            System.out.println();
        }

        // Calculate in-degree and out-degree
        for (int i = 0; i < vertices; i++) {
            int inDegree = 0;
            int outDegree = 0;

            for (int j = 0; j < vertices; j++) {
                outDegree += graph[i][j];
                inDegree += graph[j][i];
            }

            System.out.println("Vertex " + i
                    + " - In-degree: " + inDegree
                    + ", Out-degree: " + outDegree);
        }
    }
}