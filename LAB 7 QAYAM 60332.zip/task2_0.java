/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_7graph;

/**
 *
 * @author suban
 */import java.util.Scanner;
public class task2_0 {
    
    



    static int vertices = 5;
    static int[][] graph = new int[vertices][vertices];

    static void addEdge(int u, int v) {
        graph[u][v] = 1;
        graph[v][u] = 1;
        System.out.println("Edge added successfully.");
    }

    static void removeEdge(int u, int v) {
        graph[u][v] = 0;
        graph[v][u] = 0;
        System.out.println("Edge removed successfully.");
    }

    static void displayGraph() {
        System.out.println("Adjacency Matrix:");

        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + "  ");
            }
            System.out.println();
        }
    }

    static void calculateDegree(int v) {
        int degree = 0;

        for (int i = 0; i < vertices; i++) {
            degree += graph[v][i];
        }

        System.out.println("Degree of vertex " + v + ": " + degree);
    }

    static void checkEdge(int u, int v) {
        if (graph[u][v] == 1) {
            System.out.println("Edge exists between " + u + " and " + v);
        } else {
            System.out.println("Edge does not exist between " + u + " and " + v);
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        addEdge(0, 1);
        addEdge(0, 2);
        addEdge(1, 2);
        addEdge(1, 3);
        addEdge(3, 4);

        int choice;

        do {
            System.out.println("\n1. Add Edge");
            System.out.println("2. Remove Edge");
            System.out.println("3. Display Graph");
            System.out.println("4. Calculate Degree");
            System.out.println("5. Check Edge");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            choice = input.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter two vertices: ");
                    int u = input.nextInt();
                    int v = input.nextInt();

                    if (u >= 0 && u < vertices && v >= 0 && v < vertices && u != v) {
                        addEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 2:
                    System.out.print("Enter two vertices: ");
                    u = input.nextInt();
                    v = input.nextInt();

                    if (u >= 0 && u < vertices && v >= 0 && v < vertices && u != v) {
                        removeEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 3:
                    displayGraph();
                    break;

                case 4:
                    System.out.print("Enter vertex: ");
                    u = input.nextInt();

                    if (u >= 0 && u < vertices) {
                        calculateDegree(u);
                    } else {
                        System.out.println("Invalid vertex.");
                    }
                    break;

                case 5:
                    System.out.print("Enter two vertices: ");
                    u = input.nextInt();
                    v = input.nextInt();

                    if (u >= 0 && u < vertices && v >= 0 && v < vertices) {
                        checkEdge(u, v);
                    } else {
                        System.out.println("Invalid vertices.");
                    }
                    break;

                case 0:
                    System.out.println("Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        input.close();
    }
}
