/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab_7graph;

/**
 *
 * @author suban
 * 
 * 
 */
import java.util.Scanner;
public class TASK4_0 {
    




    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int vertices = 5;
        int[][] graph = new int[vertices][vertices];

        System.out.print("Enter number of connections: ");
        int edges = sc.nextInt();

        for (int i = 0; i < edges; i++) {
            System.out.print("Enter two departments (0-4): ");
            int u = sc.nextInt();
            int v = sc.nextInt();

            if (u >= 0 && u < vertices &&
                v >= 0 && v < vertices && u != v) {
                graph[u][v] = 1;
                graph[v][u] = 1;
            } else {
                System.out.println("Invalid departments. Try again.");
                i--;
            }
        }

        // Display adjacency matrix
        System.out.println("\nAdjacency Matrix:");

        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                System.out.print(graph[i][j] + "  ");
            }
            System.out.println();
        }

        // Check direct connection
        System.out.print("\nEnter two departments to check connection: ");
        int u = sc.nextInt();
        int v = sc.nextInt();

        if (u >= 0 && u < vertices && v >= 0 && v < vertices) {
            if (graph[u][v] == 1) {
                System.out.println("Departments are directly connected.");
            } else {
                System.out.println("Departments are not directly connected.");
            }
        } else {
            System.out.println("Invalid departments.");
        }

        // Calculate degree
        System.out.print("\nEnter department to calculate degree: ");
        int department = sc.nextInt();

        if (department >= 0 && department < vertices) {
            int degree = 0;

            for (int j = 0; j < vertices; j++) {
                degree += graph[department][j];
            }

            System.out.println("Degree of department "
                    + department + ": " + degree);
        } else {
            System.out.println("Invalid department.");
        }

        sc.close();
    }
}